# Object_Detection_Tennis_House > 2024-08-20 8:59am
https://universe.roboflow.com/learningworkspace-zrodd/object_detection_tennis_house

Provided by a Roboflow user
License: CC BY 4.0

